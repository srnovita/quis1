#Program quis
#Novita Sari Siregar
#Nim: 22343008

#circular Queue
class CircularQueue:
    def __init__(self, k):
        self.k = k
        self.items = [None] * k
        self.head = 0
        self.tail = -1
        self.size = 0

    def is_empty(self):
        return self.size == 0

    def is_full(self):
        return self.size == self.k

    def enqueue(self, item):
        if self.is_full():
            return False
        self.tail = (self.tail + 1) % self.k
        self.items[self.tail] = item
        self.size += 1
        return True

    def dequeue(self):
        if self.is_empty():
            return False
        self.head = (self.head + 1) % self.k
        self.size -= 1
        return True

    def front(self):
        if self.is_empty():
            return None
        return self.items[self.head]

if __name__ == '__main__':
    terminal_queue = CircularQueue(5)

    terminal_queue.enqueue('John')
    terminal_queue.enqueue('Jane')
    terminal_queue.enqueue('Bob')
    terminal_queue.enqueue('Alice')
    terminal_queue.enqueue('Tom')

    while not terminal_queue.is_empty():
        print('Penumpang:', terminal_queue.front(), 'dalam antrian')
        terminal_queue.dequeue()