# Mendefinisikan list nilai
nilai = []

# Mengisi list dengan input nilai dari pengguna
for i in range(5):
    nilai.append(float(input("Masukkan nilai Anda: ")))

# Menentukan kelulusan berdasarkan nilai rata-rata
rata_rata = sum(nilai) / len(nilai)

if rata_rata >= 60:
    print("Selamat, Anda lulus!")
else:
    print("Maaf, Anda tidak lulus.")

# Menampilkan nilai rata-rata dan nilai individu
print("Nilai rata-rata Anda adalah:", rata_rata)

for i in range(len(nilai)):
    print("Nilai ke-", i+1, "adalah:", nilai[i])