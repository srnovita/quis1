#porgram quis
#Nama: Novita Sari Siregar
#Nim: 22343008

#linked List
class Node:
    def __init__(self, name, score, next_node=None):
        self.name = name
        self.score = score
        self.next_node = next_node

class LinkedList:
    def __init__(self):
        self.head = None

    def add_node(self, name, score):
        new_node = Node(name, score)
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next_node is not None:
                current = current.next_node
            current.next_node = new_node

    def print_list(self):
        current = self.head
        while current is not None:
            print(current.name, current.score)
            current = current.next_node

if __name__ == '__main__':
    linked_list = LinkedList()

    linked_list.add_node('John', 90)
    linked_list.add_node('Jane', 85)
    linked_list.add_node('Bob', 75)

    linked_list.print_list()

    #skip List

    import random

class Node:
    def __init__(self, value, level):
        self.value = value
        self.next = [None] * (level + 1)

class SkipList:
    def __init__(self):
        self.head = Node(-1, 16)
        self.level = 0

    def search(self, value):
        current = self.head
        for i in range(self.level, -1, -1):
            while current.next[i] and current.next[i].value < value:
                current = current.next[i]
        if current.next[0] and current.next[0].value == value:
            return True
        return False

    def insert(self, value):
        level = self.random_level()
        new_node = Node(value, level)
        update = [None] * (level + 1)
        current = self.head
        for i in range(self.level, -1, -1):
            while current.next[i] and current.next[i].value < value:
                current = current.next[i]
            update[i] = current
        if current.next[0] and current.next[0].value == value:
            return
        if level > self.level:
            for i in range(self.level + 