#program quis
#Nama: Novita Sari Siregar
#Nim: 22343008

#queue
class Queue:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return self.items == []

    def enqueue(self, item):
        self.items.append(item)

    def dequeue(self):
        return self.items.pop(0)

    def size(self):
        return len(self.items)

if __name__ == '__main__':
    book_queue = Queue()

    book_queue.enqueue('Harry Potter')
    book_queue.enqueue('Lord of The Rings')
    book_queue.enqueue('Percy Jackson')
    book_queue.enqueue('Narnia')

    while not book_queue.is_empty():
        print('Book:', book_queue.dequeue(), 'dipinjam')